cornerText <- function(text, location="topright",...){
legend(location,legend=text, bty ="n", pch=NA,...) 
}
