# The final genome assembly was subjected to PacBio reads based gap filling using PBJelly from PBSuite v15.8.24 using default parameters. PbJelly closed 64 of a total of 85 assembly gaps. 
