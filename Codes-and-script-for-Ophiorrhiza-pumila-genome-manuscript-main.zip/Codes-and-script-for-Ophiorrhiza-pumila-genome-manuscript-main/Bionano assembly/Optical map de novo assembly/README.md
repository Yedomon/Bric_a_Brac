# Codes used for Bionano de novo guided assembly
Acquired Bionano optical maps sequencing datasets were first filtered using length cutoff as 150 Kb and were used to derive Bionano de novo genome assembly. We used Canu-assembly as the reference genome to guide de novo genome assembly and generated the “.cmap” file with length cutoff as 20 Kb and at least five restriction digestion sites.
